<?php
include 'db/conexao.php';
// Desativar a exibição de erros no navegador
error_reporting(0);    
ini_set('display_errors', 0);
// Configurar o fuso horário, caso necessário
date_default_timezone_set('America/Sao_Paulo');

// Criar Consulta
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validar e limpar os dados de entrada
    $medico_id = filter_input(INPUT_POST, 'medico_id', FILTER_VALIDATE_INT);
    $paciente_id = filter_input(INPUT_POST, 'paciente_id', FILTER_VALIDATE_INT);
    $data_consulta = filter_input(INPUT_POST, 'data_consulta', FILTER_SANITIZE_STRING);

    if ($medico_id && $paciente_id && $data_consulta) {
        // Preparar e executar a inserção no banco de dados
        $stmt = $conn->prepare("INSERT INTO consulta (medico_id, paciente_id, data_consulta) VALUES (?, ?, ?)");
        $stmt->bind_param('iis', $medico_id, $paciente_id, $data_consulta); // 'iis' corresponde aos tipos de dados (int, int, string)
        
        if ($stmt->execute()) {
            echo "Consulta criada com sucesso!";
        } else {
            echo "Erro ao criar a consulta!";
        }
        
        $stmt->close(); // Fechar a declaração preparada
    } else {
        echo "Dados inválidos. Por favor, verifique as entradas.";
    }
}

// Listar Consultas
try {
    $result = $conn->query("SELECT c.*, m.nome AS medico, p.nome AS paciente 
                            FROM consulta c 
                            JOIN medico m ON c.medico_id = m.medico_id 
                            JOIN paciente p ON c.paciente_id = p.paciente_id");

    if ($result) {
        $consultas = $result->fetch_all(MYSQLI_ASSOC); // Usar fetch_all para obter os resultados como array associativo
    } else {
        echo "Erro ao listar consultas!";
    }
} catch (Exception $e) {
    echo "Erro ao listar consultas: " . $e->getMessage();
}

// Listar Médicos
try {
    $result = $conn->query("SELECT * FROM medico");

    if ($result) {
        $medicos = $result->fetch_all(MYSQLI_ASSOC); // Usar fetch_all para médicos
    } else {
        echo "Erro ao listar médicos!";
    }
} catch (Exception $e) {
    echo "Erro ao listar médicos: " . $e->getMessage();
}

// Listar Pacientes
try {
    $result = $conn->query("SELECT * FROM paciente");

    if ($result) {
        $pacientes = $result->fetch_all(MYSQLI_ASSOC); // Usar fetch_all para pacientes
    } else {
        echo "Erro ao listar pacientes!";
    }
} catch (Exception $e) {
    echo "Erro ao listar pacientes: " . $e->getMessage();
}
?>


<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="shortcut icon" href="img/hospital.png" type="image/x-icon">
    <link rel="stylesheet" href="css/styleConsulta.css">
    <title>Health</title>
</head>
<body>
<header>
        <nav class="navgation">
            <a href="index.html" class="logo">Health</a>
            <ul class="nav-menu">
                <li class="nav_item"><a href="index.html">Home</a></li>
                <li class="nav_item"><a href="perfil.php">Perfil</a></li>
                <li class="nav_item"><a href="index.html">Clínica</a></li>
                <li class="nav_item"><a href="index.html">Localização</a></li>
                <li class="nav_item"><a href="logout.php">Sair</a></li>
            </ul>
            <div class="menu ativo">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </div>
        </nav>
    </header>
    <h1>Cadastro de Consultas</h1>
    <form method="POST">
        <select name="medico_id" required>
            <option value="">Selecione o Médico</option>
            <?php foreach ($medicos as $medico): ?>
                <option value="<?= $medico['medico_id'] ?>"><?= $medico['nome'] ?></option>
            <?php endforeach; ?>
        </select>

        <select name="paciente_id" required>
            <option value="">Selecione o Paciente</option>
            <?php foreach ($pacientes as $paciente): ?>
                <option value="<?= $paciente['paciente_id'] ?>"><?= $paciente['nome'] ?></option>
            <?php endforeach; ?>
        </select>

        <input type="datetime-local" name="data_consulta" required>
        <button type="submit">Adicionar</button>
    </form>
</body>
</html>
