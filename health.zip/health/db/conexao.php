<?php
    $server = "localhost";
    $username = "root";
    $senha = "";
    $database = "health";

    $conn = new mysqli($server, $username, $senha, $database);

    if($conn->connect_error){
        die("Conexão falhou: " . $conn->connect_error);
    }
?>