-- Criação do banco de dados
CREATE DATABASE clinica;
USE clinica;

-- Tabela médico
CREATE TABLE medico (
    medico_id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    especialidade VARCHAR(100) NOT NULL,
    crm VARCHAR(20) UNIQUE NOT NULL
);

-- Tabela paciente
CREATE TABLE paciente (
    paciente_id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    data_nascimento DATE NOT NULL,
    telefone VARCHAR(15)
);

-- Tabela consulta
CREATE TABLE consulta (
    consulta_id INT AUTO_INCREMENT PRIMARY KEY,
    paciente_id INT,
    medico_id INT,
    especialidade varchar (30) not null,
    data_consulta DATETIME NOT NULL,
    descricao TEXT,
    FOREIGN KEY (paciente_id) REFERENCES paciente(paciente_id),
    FOREIGN KEY (medico_id) REFERENCES medico(medico_id)
);
