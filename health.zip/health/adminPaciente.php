<!DOCTYPE html>
<html lang="pt_BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/hospital.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/admin.css">
    <title>Health | admin</title>
</head>
<body>
<header>
        <nav class="navgation">
            <a href="index.html" class="logo">Health</a>
            <ul class="nav-menu">
                <li class="nav_item"><a href="adminPaciente.php">Paciente</a></li>
                <li class="nav_item"><a href="adminMedico.php">Médico</a></li>
            </ul>
        </nav>
    </header>
    <div class="container">
        <div class="cadastro">
            <h1>cadastre um novo filiado</h1>
            <form method="post">
                <label for="nome">Nome:</label>
                <input type="text" name="nome" required placeholder="Digite o nome">

                <label for="senha">Senha:</label>
                <input type="password" name="senha" required required placeholder="Digite a senha">

                <label for="nascimento">Telefone:</label>
                <input type="date" name="nascimento" required required placeholder="10/10/1001">

                <label for="telefone">Telefone:</label>
                <input type="tel" name="telefone" required placeholder="(11)11111-1111">

                <button type="submit" class="btn btn-primary">Cadastrar</button>
            </form>
            <?php
                include 'db/conexao.php';

                // Criar Médico
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    $nome = trim($_POST['nome']);
                    $senha = trim($_POST['senha']);
                    $nascimento = trim($_POST['nascimento']);
                    $telefone = trim($_POST['telefone']);


                    // Preparar e executar a consulta
                    $stmt = $conn->prepare("INSERT INTO paciente (nome, senha, data_nascimento, telefone) VALUES (?, ?, ?, ?)");
                    if ($stmt->execute([$nome, $senha, $nascimento, $telefone])) {
                        echo "<p>Paciente adicionado com sucesso!</p>";
                    } else {
                        echo "<p>Erro ao adicionar paciente!</p>";
                    }
                }

                // Listar Paciente
                $result = $conn->query("SELECT * FROM paciente");

                if ($result->num_rows > 0) {
                    echo "<table class='table table-striped'>";
                    echo "<tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Data de Nascimento</th>
                            <th>Telefone</th>
                        </tr>";
                    
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['paciente_id'] . "</td>";
                        echo "<td>" . $row['nome'] . "</td>";
                        echo "<td>" . $row['data_nascimento'] . "</td>";
                        echo "<td>" . $row['telefone'] . "</td>";
                        echo "</tr>";
                    }

                    echo "</table>";
                } else {
                    echo "Nenhum paciente encontrado.";
                }

            ?>
        </div>
        <div class='listagem'>
        
        </div>
    </div>
</body>
</html>