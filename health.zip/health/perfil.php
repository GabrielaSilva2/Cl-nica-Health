<?php
     
?>
<!DOCTYPE html>
<html lang="pt-BR">
    <head>
        <title>Health</title>
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link rel="shortcut icon" href="img/hospital.png" type="image/x-icon">
        <link rel="stylesheet" href="css/padrao.css">
        <link rel="stylesheet" href="css/stylePerfil.css">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            .btn-agendamento {
                display: flex;
                justify-content: center; 
                align-items: center; 
                height: 100vh; 
                padding: 0px 5%;
            }

            .btn-ag {
                width: 200px;
                margin-right: 50px;
                height: auto;
                padding: 7px 30px;
                background-color: #eaf3fe;
                box-shadow: 10px 10px 20px rgba(5, 138, 247, 0.326);
            }

            .btn-ag:hover {
                background-color: #71b1ff;
                color:#eaf3fe;
                box-shadow: 10px 10px 20px rgba(2, 94, 169, 0.605);
            }
            .btn-ag img {
                align-items: center;
            }
            .btn-ag p{
                text-align: center;
                font-size: 1rem;
                color: #0455BF;
                margin-top: 10px;
                margin-bottom: 10px;
            }
        </style>
    </head>
<body>
    <header>
        <nav class="navgation">
            <a href="index.html" class="logo">Health</a>
            <ul class="nav-menu">
                <li class="nav_item"><a href="index.html">Home</a></li>
                <li class="nav_item"><a href="index.html">Sobre</a></li>
                <li class="nav_item"><a href="index.html">Clínica</a></li>
                <li class="nav_item"><a href="index.html">Localização</a></li>
                <li class="nav_item"><a href="logout.php">Sair</a></li>
            </ul>
            <div class="menu ativo">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </div>
        </nav>
    </header>
    
    <img src="img/banner.png" alt="Consulta">
        <h1 class='titulo-perfil'>Seja bem-vindo, ao nosso portal </h1>

    <div class="btn-agendamento">

        <a href="consultas.php">
            <button class="btn-ag">
                <img src="img/medica.png" alt="Cerébro">
                <p>Agende sua consulta</p>
            </button>
        </a>

        <a href="psicologo">
            <button class="btn-ag">
                <img src="img/prontuario.png" alt="Psicologo">
                <p>Ver minhas consultas</p>
            </button>
        </a>

    </div>
   
</body>
</html>