<?php
    include "db/conexao.php";
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<title>Health</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="shortcut icon" href="img/hospital.png" type="image/x-icon">
	<link rel="stylesheet" href="css/padrao.css">
	<link rel="stylesheet" href="css/styleIndex.css">
	<script src="https://kit.fontawesome.com/a81368914c.js" defer></script>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<header>
        <nav class="navgation">
            <a href="index.html" class="logo">Health</a>
            <ul class="nav-menu">
                <li class="nav_item"><a href="index.html">Home</a></li>
                <li class="nav_item"><a href="index.html">Sobre</a></li>
                <li class="nav_item"><a href="index.html">Clínica</a></li>
                <li class="nav_item"><a href="index.html">Localização</a></li>
            </ul>
            <div class="menu ativo">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </div>
        </nav>
    </header>

	<div class="container">
		<div class="img">
			<img src="img/login.png">
		</div>
		<div class="login-content">
			<form action="login.php" method="post">
				<h2 class="title">Bem vindo</h2>
           		<div class="input-div one">
           		   <div class="i">
           		   		<i class="fas fa-user"></i>
           		   </div>
           		   <div class="div">
           		   		<h5 for="username">Nome:</h5>
           		   		<input type="text" class="input" name="nome" id="nome">
           		   </div>
           		</div>
           		<div class="input-div pass">
           		   <div class="i"> 
           		    	<i class="fas fa-lock"></i>
           		   </div>
           		   <div class="div">
           		    	<h5 for="crm">CRM:</h5>
           		    	<input type="varchar" name="crm" id="crm" class="input">
            	   </div>
            	</div>
            	<input type="submit" class="btn" value="Login">
            </form>
        </div>
    </div>
    <script type="text/javascript" src="js/main.js"></script>
</body>
</html>
<?php

// Verifica se os dados foram enviados via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome']);
    $crm = trim($_POST['crm']);

    // Preparar consulta para buscar o usuário
    $stmt = $conn->prepare("SELECT * FROM medico WHERE nome = ?");
    $stmt->bind_param("s", $nome);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Usuário encontrado, verificar senha
        $usuario = $result->fetch_assoc();
        
        if (crm_verify($crm, $usuario['senha'])) {
            echo "Login realizado com sucesso! Bem-vindo, " . $usuario['nome'];
            // Redireciona para a página de perfil
            header("Location: perfilM.php");
            exit; // Importante para garantir o redirecionamento
        } else {
            // Senha incorreta
            echo "Senha incorreta!";
            header("Location: perfilM.php");
        }
    } else {
        // Nenhum usuário encontrado com o nome fornecido
        echo "Usuário não encontrado!";
    }

    // Fechar a consulta
    $stmt->close();
}

// Fechar a conexão com o banco de dados
$conn->close();
?>


