<?php
include 'db/conexao.php';
// Desativar a exibição de erros no navegador
//error_reporting(0);    
//ini_set('display_errors', 0);

// Iniciar a sessão
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    echo "Você precisa estar logado para ver suas consultas.";
    exit;
}

// Obter o ID do usuário logado da sessão
$usuario_id = $_SESSION['usuario_id'];
// Preparar a consulta para selecionar as consultas do usuário logado
$sql = "SELECT id, data, medico FROM consulta WHERE usuario_id = ?";

// Preparar a consulta SQL
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $usuario_id); // Vincular o ID do usuário
$stmt->execute();
$result = $stmt->get_result(); // Executar e obter o resultado

// Verificar se existem consultas
if ($result->num_rows > 0) {
    echo "<h2>Suas Consultas</h2>";
    echo "<table border='1'>
            <tr>
                <th>ID</th>
                <th>Data</th>
                <th>Descrição</th>
            </tr>";
    
    // Loop para exibir os registros das consultas
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row['id'] . "</td>
                <td>" . date('d/m/Y', strtotime($row['data'])) . "</td>
                <td>" . htmlspecialchars($row['medico']) . "</td>
              </tr>";
    }
    
    echo "</table>";
} else {
    echo "Você não tem consultas registradas.";
}
?>




<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="shortcut icon" href="img/hospital.png" type="image/x-icon">
    <link rel="stylesheet" href="css/styleConsulta.css">
    <title>Health</title>
</head>
<body>
<header>
        <nav class="navgation">
            <a href="index.html" class="logo">Health</a>
            <ul class="nav-menu">
                <li class="nav_item"><a href="index.html">Home</a></li>
                <li class="nav_item"><a href="perfil.php">Perfil</a></li>
                <li class="nav_item"><a href="index.html">Clínica</a></li>
                <li class="nav_item"><a href="index.html">Localização</a></li>
                <li class="nav_item"><a href="logout.php">Sair</a></li>
            </ul>
            <div class="menu ativo">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </div>
        </nav>
    </header>
    <h1>Minhas consultas</h1>

</body>
</html>
