<?php
// Inicia a sessão
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    // Se o usuário não está logado, redireciona para a página de login
    header("Location: login.php");
    exit; // Garante que o script pare de ser executado
}
?>
